import json
import os

try:
    with open('./.env.json') as env_file:
        config = json.load(env_file)
    for key, value in config.items():
        os.environ[key] = str(value)
except IOError:
    pass

from index import handle
